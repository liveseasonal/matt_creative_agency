<?php 	
	$edge_border = '<div class="km-filter-it-link-edge filteri-edgeright"></div><div class="km-filter-it-link-edge filteri-edgeleft"></div>';
	echo kameleon_portfolio_filter($cats_array = false, '', $edge_border,'30','style3','center','km-simple-filter');
?>
