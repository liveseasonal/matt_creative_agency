<?php $sy_options = kameleon_get_options_name(); ?>
<div id="km-footer-icons">
	<?php sy_social_links(); ?>
</div>	