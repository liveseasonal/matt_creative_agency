<?php $sy_options = kameleon_get_options_name(); ?>
<div id="km-footer-copyright-container">
	<div id="km-footer-copyright-content" class="center-content">
		<?php echo wp_kses_data($sy_options['footer_copyright_content']); ?>
	</div>
</div>