------------------------------------------------------------------
------------------------------------------------------------------
			Thanks for purchasing Kameleon Theme
------------------------------------------------------------------
------------------------------------------------------------------


You must install and activate the KAMELEON_CORE Plugin to get all Kameleon theme capabilities and options.
Note : if you are aiming to import demo data you MUST activate all the provided plugins to prevent any unexpected errors or wierd behaviors


Contact us for more information == sayen.themes@gmail.com

SayenThemes team promise you to do the best to make your Kameleon Theme experience Great


THANK YOU AGAIN FOR PURCHASING KAMELEON THEME
