<form role="search" method="get" id="searchform" action="<?php echo esc_url(home_url( '/' )); ?>">
    <div>
        <input type="text" value="" placeholder="<?php echo esc_attr('Search Site'); ?>" name="s" id="s" />        
    </div>
</form>