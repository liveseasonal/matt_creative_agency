<?php 	
	get_header(); 	
?>

<div id="km-content" >
	<div id="km-checker">
		<div id="km-data" class="center-content">
		<div id="page404">
			<div id="page404-text">
				<div id="page404-title">
					<span id="span-404">404</span> 
					<span id="page404-msg"><?php echo esc_html__('PAGE NOT FOUND.','kameleon'); ?></span>
					<div id="page404-iconRound">
						<i class="Defaults-km-icon-chain-broken"></i>					
					</div>
				</div>
			</div>
		</div>	
		</div>
		

	</div>
</div>




<?php get_footer();?>